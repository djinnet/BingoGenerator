How to compile SASS:
1. Install SASS on your computer.
2. Download the SASS source from Bootstrap and put it inside the source folder.
3. Run sass blazor.scss ../blazor.css